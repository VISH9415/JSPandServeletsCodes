package com.cg.jspdemo.exception;

public class InvalidConsumerNumberException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public InvalidConsumerNumberException(String msg) {
		super(msg);
		//System.out.println(msg);
	}
	

	

	
	
	
	
	
	
	
}
