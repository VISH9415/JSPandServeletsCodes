

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	String user = request.getParameter("username");
	PrintWriter out= response.getWriter();
	if(user.equals("capgemini")){
		HttpSession session = request.getSession();
		session.setAttribute("userName",user);
		out.println("<br>Welcome..."+user);
		out.println("<br>is it a new session ?"+session.isNew());
		Date dt = new Date(session.getCreationTime());
		out.println("<br>Created at ?"+dt.toString());
		out.println("<br>Session id ?"+session.getId());
		out.println("<br><a href=BillingServlet>Click here for billing details</a>");
	}
	else
	{
		response.sendRedirect("index.html");
	}
	}

}
