package com.cg.servletdemo.day3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String prodname = request.getParameter("pname");
		String price = request.getParameter("price");
		String quantity = request.getParameter("quantity");
	
		if(prodname.matches("[A-Za-z]{5,}$") && price.matches("^[0-9]{1,}$") && quantity.matches("[0-9]{1,}$"))
		{
		request.setAttribute("prodName",prodname);
		request.setAttribute("price",price);
		request.setAttribute("quantity",quantity);
		
		RequestDispatcher rd= request.getRequestDispatcher("DisplayProductServlet");
		PrintWriter out = response.getWriter();
		out.println("Hello...you are in product servelet.....");
		rd.include(request, response);
	      } 
		else{
			response.sendRedirect("Error.html");
		}
	}
	}
