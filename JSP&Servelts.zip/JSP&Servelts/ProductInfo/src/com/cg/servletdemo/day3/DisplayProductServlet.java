package com.cg.servletdemo.day3;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayProductServlet
 */
@WebServlet("/DisplayProductServlet")
public class DisplayProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String pname = (String) request.getAttribute("prodName");
		String price = (String) request.getAttribute("price");
		String quantity = (String) request.getAttribute("quantity");
		
		int total = Integer.parseInt(price)*Integer.parseInt(quantity);
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("Product names are below.... we are in displayproductservlet");
		out.println("<br> Product Name: "+pname);
		out.println("<br> Product Price: "+price);
		out.println("<br> Product Quantity: "+quantity);
		out.println("<br> Product total price: "+total);
		out.println("</body></html>");
	}

}
