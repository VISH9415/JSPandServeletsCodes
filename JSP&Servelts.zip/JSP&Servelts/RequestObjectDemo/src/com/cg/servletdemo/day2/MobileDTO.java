package com.cg.servletdemo.day2;


public class MobileDTO {
    private int mobId;
    private int quantity;
    private String mobName;
    private int mobPrice;
    
	public MobileDTO(int mobId, int quantity, String mobName, int mobPrice) {
		super();
		this.mobId = mobId;
		this.quantity = quantity;
		this.mobName = mobName;
		this.mobPrice = mobPrice;
	}
	
	public MobileDTO() {
		super();
	}
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public int getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(int mobPrice) {
		this.mobPrice = mobPrice;
	}



    

}
