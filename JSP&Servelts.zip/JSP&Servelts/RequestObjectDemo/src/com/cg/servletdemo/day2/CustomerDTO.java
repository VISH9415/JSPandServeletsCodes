package com.cg.servletdemo.day2;

import java.time.LocalDate;



public class CustomerDTO {
	private int purchaseId;
    private String customerName;
    private String mailId;
    private String phoneNo; 
    private LocalDate purchaseDate;
    private int mobileId;
     
	public CustomerDTO() {
		super();
	}
	
	public CustomerDTO(int purchaseId, String customerName, String mailId,
			String phoneNo, LocalDate purchaseDate, int mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}



	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	
}
