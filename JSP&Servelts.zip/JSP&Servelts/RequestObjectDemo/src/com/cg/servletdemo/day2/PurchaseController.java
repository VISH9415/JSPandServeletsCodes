package com.cg.servletdemo.day2;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PurchaseController
 */
@WebServlet("/PurchaseController")
public class PurchaseController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	//MobileDTO mobile;
	
	
    public PurchaseController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path= request.getQueryString();
		if(request.getParameter("action").equals("acceptDetails")){
		CustomerDTO customer = new CustomerDTO();
		String cName = request.getParameter("custname");
		String mobno = request.getParameter("mobileno");
		String email = request.getParameter("mailid");
		String mobileid = request.getParameter("mobileid");
		String pdate = request.getParameter("purdate");
		
		customer.setCustomerName(cName);
		customer.setPhoneNo(mobno);
		customer.setMailId(email);
		customer.setMobileId(Integer.parseInt(mobileid));
		
		//date is taken in string format only...
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate dt = LocalDate.parse(pdate,formatter);
		customer.setPurchaseDate(dt);
		
		
		
		/*out.println("Purchase details are inserted successfully...");
		out.println("<br>your cust id is: "+customer.getCustomerName());
		out.println("<br>your mobile id is: "+customer.getMobileId());
		out.println("<br>your mobile no. is: "+customer.getPhoneNo());
		out.println("<br>your email id is: "+customer.getMailId());
		out.println("<br>"+path);*/
		//response.sendRedirect("success.html");

		
	}	
	}

}
